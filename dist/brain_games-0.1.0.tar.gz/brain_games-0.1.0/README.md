### Hexlet tests and linter status:
[![Actions Status](https://github.com/patronussun/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/patronussun/python-project-49/actions)

<a href="https://codeclimate.com/github/patronussun/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/2686d1fe2356ed647087/maintainability" /></a>